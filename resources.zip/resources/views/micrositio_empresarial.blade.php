<!doctype html>
<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="{{ url('css/slick_empresarial.css') }}"/>
    <link rel="stylesheet" type="text/css" href="{{ url('css/slick-theme_empresarial.css') }}"/>
    <link rel="stylesheet" href="{{ url('css/app_empresarial.css') }}">
    <title>{{$registro->sucursal}}</title>
    <link rel="icon" type="image/png" href="https://socasesores.com/img/favicon.png">
    <style type="text/css">
      /* Set the size of the div element that contains the map */
      #map {
        height: 300px;
        /* The height is 400 pixels */
        width: 100%;
        /* The width is the width of the web page */
      }
    </style>
    <script>
      // Initialize and add the map
      function initMap() {
        // The location of Uluru
        const uluru = { lat: {{$registro->lat}}, lng: {{$registro->lng}} };
        // The map, centered at Uluru
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 15,
          center: uluru,
        });
        // The marker, positioned at Uluru
        const marker = new google.maps.Marker({
          position: uluru,
          map: map,
        });
      }
    </script>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PWWWBX');</script>
    <!-- End Google Tag Manager -->
  </head>
        @if ($registro->certificacion == "Plata")
        <body class="plata-2">
        <header class="fixed-top">
            <a class="certificado">
                <img src="{{ url('img/Certificaciones-03.png') }}" alt="">
            </a>
        @elseif ($registro->certificacion == "Oro")
        <body class="oro-2">
        <header class="fixed-top oro">
            <a class="certificado">
                <img src="{{ url('img/Certificaciones-02.png') }}" alt="">
            </a>
        @elseif($registro->certificacion == "Diamante")
        <body class="diamante-2">
        <header class="fixed-top diamante">
            <a class="certificado">
                <img src="{{ url('img/Certificaciones-01.png') }}" alt=""> 
            </a>
        @else
        <body >
            <header class="fixed-top">
        @endif
        
            @if($registro->whatsapp != null)
            <a href="https://api.whatsapp.com/send?phone=521{{$registro->whatsapp}}" target="_blank" class="position-fixed" style="bottom: 10px; right: 10px;"><img style="width: 40px" src="{{ url('img/whatsapp.png') }}" alt=""></a>
        @else
            <a href="https://api.whatsapp.com/send?phone=521{{$registro->telefono}}" target="_blank" class="position-fixed" style="bottom: 10px; right: 10px;"><img style="width: 40px" src="{{ url('img/whatsapp.png') }}" alt=""></a>
        @endif
      
        <section class="top-head">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h1>Crédito Empresarial</h1>
                    </div>
                    @if ($registro->certificacion == 1)
                        <div class="oficina">
                            <p><a class="link-certificado"><img src="{{ url('img/logo_plata.svg') }}" alt=""></a></p>
                        </div>
                    @elseif ($registro->certificacion == 2)
                        <div class="oficina">
                            <p><a class="link-certificado"><img src="{{ url('img/logo_oro.svg') }}" alt=""></a></p>
                        </div>
                    @elseif($registro->certificacion == 3)
                        <div class="oficina">
                            <p><a class="link-certificado"><img src="{{ url('img/logo_diamante.svg') }}" alt=""></a></p>
                        </div>
                    @else
                    @endif
                </div>
            </div>
        </section>
        <section class="menu">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        @if ($registro->certificacion == "Plata")
                        <nav class="navbar navbar-expand-lg navbar-light bg-light menu-em" style="margin-top: 20px">
                            <div class="text-md-center text-center ml-md-4 movil-log">
                                    <a class="navbar-brand d-flex align-items-center text-left" href="#">
                        @elseif ($registro->certificacion == "Oro")
                            <nav class="navbar navbar-expand-lg navbar-light bg-light menu-em" style="margin-top: 20px">
                                 <div class="text-md-center text-center ml-md-4 movil-log">
                                    <a class="navbar-brand d-flex align-items-center text-left" href="#">
                        @elseif($registro->certificacion == "Diamante")
                            <nav class="navbar navbar-expand-lg navbar-light bg-light menu-em" style="margin-top: 20px">
                                <div class="text-md-center text-center ml-md-4 movil-log">
                                    <a class="navbar-brand d-flex align-items-center text-left" href="#">
                        @else
                            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                                <div class="text-md-center text-center ml-md-4">
                                    <a class="navbar-brand d-flex align-items-center text-left" href="#">
                        @endif
                            <a class="navbar-brand" href="#">
                                @if ($registro->logo != null)
                                    <img src="{{url('https://socasesores.com/micrositios-empresarial/img/brokers')}}/{{$registro->logo}}" class="d-inline-block align-top ml-0" style="border-right: 0px; max-width: 200px" alt="">
                                @else
                                    @php
                                     $split = explode("-", $registro->name);
                                    @endphp
                                    @if($registro->type == 2)
                                        <img src="{{ url('img/logo-SOC.jpg') }}" class="d-inline-block 
                                    align-top" alt=""> <span style="text-transform: none;">{{ $split[0] }}</span>
                                    @else
                                        <img src="{{ url('img/logo-SOC.jpg') }}" class="d-inline-block 
                                    align-top" alt=""> <span>{{ $split[0] }}</span>
                                    @endif
                                @endif
                            </a>
                            <img class="img-bot" src="{{ url('img/logo_bot.jpg') }}" alt="">
                            </div>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                              <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                              <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                                <li class="nav-item">
                                  <a class="nav-link" href="#productos">Productos</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#contacto">Contáctanos</a>
                                  </li>
                              </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
    </header>
    <main>
        @if($registro->diseño == "quos")
            <section class="home-1">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-md-7">
                            <h1>Antes de hacer crecer tu negocio, <b>piensa en SOC</b></h1>
                            <p>Somos el Broker líder en asesoría financiera en México.</p>
                            <p style="font-size: 1rem;">Con más de 17 años de experiencia, brindamos la mejor asesoría en créditos PyME, 0% de comisión por nuestros servicios financieros especializados de forma más eficiente el proceso de financiamiento con nuestra asesoría de alta calidad.</p>
                        <form action="{{ route('sendMail2') }}" method="post" style="margin-bottom: 2rem;">
                            @csrf
                            <div class="form-group">
                                <input type="text" class="d-none" name="email_cliente" value="{{$registro->email}}" required>
                                <input type="text" class="d-none" name="url" value="{{$registro->url}}" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="">Nombre</label><br>
                                    <input type="text" class="form-control" name="name"><br>
                                    <label for="">Teléfono</label><br>
                                    <input type="text" class="form-control" name="phone"><br>
                                </div>
                                <div class="col-md-6">
                                    <label for="">Correo electrónico</label><br>
                                    <input type="text" class="form-control" name="email"><br>
                                    <label for="">Producto de interés</label><br>
                                    <input type="text" class="form-control" name="type"><br>
                                </div>
                                <div class="col-12 text-center">
                                    <input type="submit" class="btn btn-success" value="Contáctanos">
                                </div>
                            </div>
                        </form>
                        </div>
                        <div class="col-md-5">
                            <img src="{{ url('https://socasesores.com/micrositios-empresarial/img/Grupo_1546.png') }}" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </section>
        @else
            <section class="home-1">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <h1>Antes de hacer crecer tu negocio, <b>piensa en SOC</b></h1>
                            <p>Broker líder en asesoría financiera en México.</p>
                        </div>
                        <div class="col-md-6">
                            <img src="{{ url('https://socasesores.com/micrositios-empresarial/img/Grupo_1546.png') }}" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </section>
        @endif
        <section class="home-2">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 col-12">

                            <p>Te acompañamos durante todo el proceso, hasta el fondeo de tu crédito</p>
                        
                        
                    </div>
                    <div class="col-md-6 col-12">
                        @if ($registro->imagen_1 != null)
                            <img class="img-fluid" src="{{url('https://socasesores.com/micrositios-empresarial/img/brokers')}}/{{$registro->imagen_1}}" alt="">
                        @else
                            <img class="img-fluid" src="{{url('https://socasesores.com/micrositios-empresarial/img/servicios_1.jpg')}}" alt="">
                        @endif
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-md-6 col-12">
                        @if ($registro->imagen_2 != null)
                            <img class="img-fluid" src="{{url('https://socasesores.com/micrositios-empresarial/img/brokers')}}/{{$registro->imagen_2}}" alt="">
                        @else
                            <img class="img-fluid" src="{{url('https://socasesores.com/micrositios-empresarial/img/servicios_2.jpg')}}" alt="">
                        @endif
                    </div>
                    <div class="col-md-6 col-12">
                        <p><span>Nuestro servicio no tiene costo, porque la institución financiera que elijas será la que cubrirá nuestros honorarios.</span></p>
                    </div>
                </div>
            </div>
        </section>
        <div id="productos"></div>
        <section class="home-3">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        @php
                            $productos = explode(",", $registro->productos);
                        @endphp
                        <h2>Productos</h2>
                        <div class="multiple-items d-none d-sm-block">
                        @if(isset($productos))
                        @foreach($productos as $producto)
                        @switch($producto)
                            @case("Crédito como anticipo de ventas")
                                <div class="content-slide">
                                    <a href="" data-toggle="modal" data-target=".product_1">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/anticipo.jpg')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Anticipo de ventas</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break

                            @case("Crédito Simple")
                                <div class="content-slide">
                                    <a href="" data-toggle="modal" data-target=".product_2">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_1.png')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Simple</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Crédito Revolvente")
                                <div class="content-slide">
                                    <a href="" data-toggle="modal" data-target=".product_3">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_2.png')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Revolvente</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Crédito de Arrendamiento")
                                <div class="content-slide">
                                    <a href="" data-toggle="modal" data-target=".product_4">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_4.png')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Arrendamiento</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Tarjeta de Crédito")
                                <div class="content-slide">
                                    <a href="" data-toggle="modal" data-target=".product_5">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_5.jpg')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito</p>
                                                <p>Tarjeta de crédito</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break

                            @case("Crédito Hipotecario Empresarial")
                                <div class="content-slide">
                                    <a href="" data-toggle="modal" data-target=".product_6">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_6.jpg')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito</p>
                                                <p>Hipotecario Empresarial</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                       @endswitch
                        @endforeach
                           @endif
                        </div>
                        <div class="productos_movil row justify-content-center d-block d-sm-none">
                        @if(isset($productos))
                            @foreach($productos as $producto)
                            @switch($producto)

                            @case("Crédito como anticipo de ventas")
                                <div class="content-slide col-10 mb-4">
                                    <a href="" data-toggle="modal" data-target=".product_1">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/anticipo.jpg')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Anticipo de ventas</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                             @case("Crédito Simple")
                                <div class="content-slide col-10 mb-4">
                                    <a href="" data-toggle="modal" data-target=".product_2">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_1.png')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Simple</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Crédito Revolvente")
                                <div class="content-slide col-10 mb-4">
                                    <a href="" data-toggle="modal" data-target=".product_3">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_2.png')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Revolvente</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Crédito de Arrendamiento")
                                <div class="content-slide col-10 mb-4">
                                    <a href="" data-toggle="modal" data-target=".product_4">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_4.png')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Arrendamiento</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Tarjeta de Crédito")
                                <div class="content-slide col-10 mb-4">
                                    <a href="" data-toggle="modal" data-target=".product_5">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_5.jpg')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito</p>
                                                <p>Tarjeta de crédito</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break
                            @case("Crédito Hipotecario Empresarial")
                                <div class="content-slide col-10 mb-4">
                                    <a href="" data-toggle="modal" data-target=".product_6">
                                        <div class="info">
                                            <img src="{{url('https://socasesores.com/micrositios-empresarial/img/empre_6.jpg')}}" alt="">
                                            <div class="description-slide">
                                                <p>Crédito Empresarial</p>
                                                <p>Hipotecario empresarial</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @break    
                        @endswitch
                        @endforeach
                           @endif
                           
                        </div>                                 
                    </div>
                </div>
            </div>
        </section>
        <section class="home-4">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-12 col-lg-3 col-md-4">
                        <h2 class="text-left">Socios Comerciales</h2>
                    </div>
                    <div class="col-12 col-lg-5 col-md-8">
                        <div class="row align-items-center">
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_308@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_322@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_185@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_287@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_296@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_324@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_327@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Anticipa@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_302@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_330@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_332@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_334@2x.png')}}" alt="">
                            </div>
                            <div class="col-6 col-md-3 mb-4">
                                <img src="{{url('https://socasesores.com/micrositios-empresarial/img/Grupo_335@2x.png')}}" alt="">
                            </div>
                            
                            <div id="cotizador"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        @if($registro->diseño == "quos")

        @else
            <!--<section class="calculadora">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-md-10 text-center">
                            <p><b>Calcula el credito para tu negocio</b></p>
                            <p>Te ayudamos a elegir y tramitar el financiamiento que tu empresa necesita para crecer</p>
                            <a href="https://socasesores.com/calculadora-creditos-empresariales/" target="_blank">Da click aquí</a>
                        </div>
                    </div>
                </div>
            </section>-->
        @endif
        <section class="home-6">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <h2>Conoce nuestras instalaciones</h2>
                    </div>
                    <div class="col-lg-9 col-12">
                        <div class="row">
                             @php
                                
                                if ($registro->oficinas != "") {
                                    $oficinas =  explode(",", $registro->oficinas);
                                }else{
                                    $oficinas = "";
                                }
                            @endphp
                            @if($oficinas != "")
                                @foreach($oficinas as $oficina)
                                    <div class="col-md-4 col-12">
                                        <div class="content" style="background-image: url(https://socasesores.com/micrositios-app/storage/app/public/images/oficinas/{{$oficina}});">
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <div class="col-md-4 col-12">
                                    <div class="content" style="background-image: url({{url('img/oficina_1.jpeg')}}">
                                    </div>
                                </div>
                                <div class="col-md-4 col-12">
                                    <div class="content" style="background-image: url({{url('img/oficina_2.jpeg')}}">
                                    </div>
                                </div>
                                <div class="col-md-4 col-12">
                                    <div class="content" style="background-image: url({{url('img/oficina_3.jpeg')}}">
                                    </div>
                                </div>
                                <div class="col-md-4 col-12">
                                    <div class="content" style="background-image: url({{url('img/oficina_4.jpeg')}}">
                                    </div>
                                </div>
                                <div class="col-md-4 col-12">
                                    <div class="content" style="background-image: url({{url('img/oficina_5.jpeg')}}">
                                    </div>
                                </div>
                                <div class="col-md-4 col-12">
                                    <div class="content" style="background-image: url({{url('img/oficina_6.jpeg')}}">
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div id="contacto"></div>
        </section>
        <section class="home-7">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-10 col-12">
                        <div class="col-12 text-center">
                            <h2>Contáctanos</h2>
                            <p>Déjanos un mensaje o usa nuestros medios de contacto directo</p>
                        </div>
                        <div class="row justify-content-between align-items-center">
                            <div class="col-md-5 mb-4 mb-md-0">
                                <form action="{{ route('sendMail') }}" method="post">
                                    @csrf
                                    <div class="form-group">
                                        <input type="text" class="d-none" name="email_cliente" value="{{$registro->email}}" required>
                                        <input type="text" class="d-none" name="url" value="{{$registro->url}}" required>
                                    </div>
                                    <div class="form-group">
                                      <label for="formGroupExampleInput">Nombre</label>
                                      <input type="text" name="name" class="form-control" id="formGroupExampleInput" placeholder="Mi nombre es">
                                    </div>
                                    <div class="form-group">
                                      <label for="formGroupExampleInput2">Correo Electrónico</label>
                                      <input type="text" name="phone" class="form-control" id="formGroupExampleInput2" placeholder="Correo@gmail.com">
                                    </div>
                                    <div class="form-group">
                                        <label for="formGroupExampleInput2">Teléfono</label>
                                        <input type="text" name="phone" class="form-control" id="formGroupExampleInput2" placeholder="55 0000 0000">
                                    </div>
                                    <div class="form-group">
                                        <label for="formGroupExampleInput2">Déjanos un mensaje</label>
                                        <textarea name="message" id="" cols="30" rows="5" class="form-control" placeholder="Escribenos tus dudas"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Enviar" class="w-100 btn btn-success">
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                        <label class="form-check-label label-terms" for="defaultCheck1">
                                            Al dar click en enviar, aceptas las <b>Condiciones de uso</b> y <b>el Aviso de privacidad</b>
                                        </label>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-5 contact-info">
                                <div class="mb-4">
                                    <p><b>Horario de atención</b></p>
                                    <p>{{$registro->horario}}</p>
                                </div>
                                <div class="mb-4">
                                    <p><b>Atención al cliente</b></p>
                     
                                    <p>{!! $registro->telefono !!}</p>
                                    <p>{{$registro->email}}</p>
                                </div>
                                <div class="mb-4">
                                    <p>{{$registro->direccion}}<br></p>
                                <div id="map"></div>
                                    @if ($registro->facebook != null)
                                        <p><br>Siguenos en nuestras redes sociales</p>
                                    @endif
                                </div>
                                <div class="mb-4">
                                   
                                        <ul>
                                            @if ($registro->facebook != null)
                                            <li><a target="_blank" href="{{$registro->facebook}}"><img src="{{ url('img/001-facebook.png') }}" alt=""></a></li>
                                            @endif
                                            @if ($registro->linkedin != null)
                                            <li><a target="_blank" href="{{$registro->linkedin}}"><img src="{{ url('img/002-linkedin.png') }}" alt=""></a></li>
                                            @endif
                                            @if ($registro->instagram != null)
                                            <li><a target="_blank" href="{{$registro->instagram}}"><img src="{{ url('img/003-instagram.png') }}" alt=""></a></li>
                                            @endif
                                            @if ($registro->twitter != null)
                                            <li><a target="_blank" href="{{$registro->twitter}}"><img src="{{ url('img/004-twitter.png') }}" alt=""></a></li>
                                            @endif
                                            @if ($registro->youtube != null)
                                            <li><a target="_blank" href="{{$registro->youtube}}"><img src="{{ url('img/005-youtube.png') }}" alt=""></a></li>
                                            @endif

                                        </ul>
                                   
                                </div>
                                @if ($registro->certificacion == 1)
                                    <div class="d-flex align-items-center">
                                        <img src="{{ url('https://socasesores.com/micrositios-empresarial/img/Certificaciones-03.png') }}" class="img-fluid mr-4" width="90" alt="">
                                        <p>Oficina con <br><b>Certificación Plata</b></p>
                                    </div>
                                @elseif ($registro->certificacion == 2)
                                <div class="d-flex align-items-center">
                                        <img src="{{ url('https://socasesores.com/micrositios-empresarial/img/Certificaciones-02.png') }}" class="img-fluid mr-4" width="90" alt="">
                                        <p>Oficina con <br><b>Certificación oro</b></p>
                                    </div>
                                @elseif($registro->certificacion == 3)
                                <div class="d-flex align-items-center">
                                        <img src="{{ url('https://socasesores.com/micrositios-empresarial/img/Certificaciones-01.png') }}" class="img-fluid mr-4" width="90" alt="">
                                        <p>Oficina con <br><b>Certificación Diamante</b></p>
                                    </div>
                                @else
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-3 col-8">
                    <img src="{{ url('https://socasesores.com/micrositios-empresarial/img/soc_blanco.png') }}" alt="">
                </div>
                <div class="col-md-3 col-12">
                    <p class="text-center"><b>Sustentado por SOC<br>Líderes en Asesoría Financiera</b></p>
                </div>
                <div class="col-md-3 col-12 text-center">
                    <a href="https://socasesores.com/terminos-y-condiciones">Términos y condiciones</a><br>
                    <a href="https://socasesores.com/aviso-de-privacidad">Aviso de privacidad</a>
                </div>
                <div class="col-md-3 col-12 text-center">
                    <a href="https://v3.sisec.mx/Pages/Login" class="sisec">Ingresa a SISEC</a>
                </div>
            </div>
        </div>
    </footer>
    <div class="modal fade product_1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="content" style="background-image: url({{ url('https://socasesores.com/micrositios-empresarial/img/anticipo.jpg') }})"></div>
                        </div>
                        <div class="col-md-6">
                            <h2>Anticipo de ventas</h2>
                            <p>Es un financiamiento que provee a los establecimientos de liquidez inmediata, en base al historial de sus ventas con tarjetas bancarias. El establecimiento Anticipa ventas futuras. Hace liquidas ventas que todavía no han sucedio.</p>
                            <ul>
                                <li>Puedes obtener desde quince días hasta mes y medio de ventas futuras.</li>
                                <li>Devuelve el anticipo conforme vayas vendiendo.</li>
                                <li>Este financiamiento no tiene un destino definido, es de uso libre.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade product_2" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="content" style="background-image: url({{ url('https://socasesores.com/micrositios-empresarial/img/empre_1_1.png') }})"></div>
                        </div>
                        <div class="col-md-6">
                            <h2>Simple</h2>
                            <p>Es un crédito que tiene un plazo entre 1 a 5 años que te permitirá obtener los recursos necesarios para cumplir los objetivos de crecimiento de tu compañía.</p>
                            <ul>
                                <li>Lo pueden obtener pequeñas y medianas empresas con sólo 1 año de antigüedad.</li>
                                <li>Tenemos opciones para Personas Morales o PFAE.</li>
                                <li>Se cuentan con algunas soluciones si no cuentas con buen historial crediticio.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade product_3" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="content" style="background-image: url({{ url('https://socasesores.com/micrositios-empresarial/img/empre_2_2.png') }})"></div>
                        </div>
                        <div class="col-md-6">
                            <h2>PyME Revolvente</h2>
                            <p>Es una línea de crédito abierta de la cual puedes disponer una parte o la totalidad de los recursos autorizados. Es ideal para cubrir necesidades de corto plazo, y una de sus ventajas es que sólo pagarás los intereses del monto que hayas dispuesto.</p>
                            
                            <ul>
                                <li>Capital de trabajo: para un uso de corto plazo, donde se requieren recursos financieros para cubrir rubros de manera inmediata.</li>
                                <li>Aprovechamiento de oportunidades en el mercado: ofertas de productos en pagos de contado o, por ejemplo, para la adquisición de mayor volumen de productos.</li>
                                <li>Lo pueden obtener pequeñas y medianas empresas con sólo 1 año de antigüedad.</li>
                                <li>Tenemos opciones para Personas Morales o PFAE.</li>
                                <li>Se cuentan con algunas soluciones si no cuentas con buen historial crediticio.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade product_4" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="content" style="background-image: url({{ url('https://socasesores.com/micrositios-empresarial/img/empre_4_4.png') }})"></div>
                        </div>
                        <div class="col-md-6">
                            <h2>Arrendamiento</h2>
                            <p>Equipa tu negocio y hazlo más productivo con una solución de arrendamiento. Te permitirá la adquisición de bienes productivos y contar con una empresa moderna dirigido a un amplio número de industrias. En SOC tenemos distintas opciones financieras para ti.</p>
                            <p>Tu empresa sólo requiere 1 año de antigüedad, buen desempeño crediticio en el Buró de Crédito, aunque también hay opciones para quienes no cumplen al 100% este punto. Se puede apoyar a una amplia variedad de industrias</p>
                            <p class="mb-0"><b>Beneficios</b></p>
                            <ul>
                                <li>Creamos un traje a la medida, ya que el financiamiento se otorga en relación directa a las necesidades del cliente.</li>
                                <li>Obtén la maquinaria o el equipo que necesitas para impulsar tu negocio sin detenerte y dejando en garantía el mismo equipo.</li>
                                <li>Aprovecha la estrategia fiscal del Arrendamiento y al final del plazo compra tu equipo o activo.</li>
                                
                            </ul>
                            <p class="mb-0"><b>Dirigido a:</b></p>
                            <ul>
                                <li>Personas Morales.</li>
                                <li>Personas Físicas con Actividad Empresarial (PFAE).</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade product_5" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="content" style="background-image: url({{ url('https://socasesores.com/micrositios-empresarial/img/empre_5.jpg') }})"></div>
                        </div>
                        <div class="col-md-6">
                            <h2>Tarjeta de crédito</h2>
                            <p>Con la tarjeta de crédito dispones de un crédito revolvente para tu empresa. Está dirigida a Personas Físicas con Actividad Empresarial y Personas Morales para la adquisición de bienes que ayuden en tus actividades empresariales y/o como capital de trabajo para el desarrollo de tu negocio.<p>
                            <p class="mb-0"><b>Beneficios</b></p>
                            <ul>
                                <li>Cuenta con el respaldo de Visa.</li>
                                <li>Seguro por pérdida de equipaje.</li>
                                <li>Seguro por Demora de equipaje.</li>
                                <li>Seguro por protección de compra.</li>
                                <li>Meses con y sin intereses según aplique.</li>
                                <li>Pago por SPEI usando la línea de crédito.</li>
                                <li>Alianza con WeWork.</li>
                                <li>Adicionales sin costo.</li>
                                <li>Posible exención del pago de anualidad.</li>
                                <li>Tarjetas para empleados con límites de gasto establecidos.</li>
                                <li>Control del gasto en tiempo real.</li>
                                <li>Tarjeta digital que podrás usar desde su aprobación.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade product_6" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="content" style="background-image: url({{ url('https://socasesores.com/micrositios-empresarial/img/empre_6.jpg') }})"></div>
                        </div>
                        <div class="col-md-6">
                            <h2>Crédito hipotecario empresarial</h2>
                            <p>Incrementa tu patrimonio al adquirir un bien inmueble como locales, oficinas, bodegas, terrenos industriales o comerciales. También, puedes remodelar o construir en un terreno propio.<p>
                            <p class="mb-0"><b>Beneficios</b></p>
                            <ul>
                                <li>No hay penalización por pagos anticipados.</li>
                                <li>La tasa de interés es fija anual durante toda la vida del crédito.</li>
                                <li>Asesoría sin costo de un experto en financiamiento para empresas.</li>
                            </ul>   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCeaHvmVaf68SRKhVbkuXqx1FJtRiApXvw&callback=initMap&libraries=&v=weekly"async></script>
    <script src="{{url('js/slick.min_empresarial.js')}}"></script>
    <script src="{{url('js/main_empresarial.js')}}"></script>
    <script>
            window.onload = function() { 
            (function (r, a, d, i, o) { 
            r['RadioAnalytics'] = i; 
            r[i] = r[i] || function () { (r[i].options = r[i].options || []).push(arguments); };  o = a.createElement("script"); 
            o.async = 1; 
            o.src = d; 
            var n = a.getElementsByTagName("script")[0]; 
            n.parentNode.insertBefore(o, n); 
            })(window, document, "https://www.statsradio.com/js/RadioAnalytics.js?ts=" + new Date().getTime(), "ra");
            ra(“DIO-FM”, { 
            audio: { 
            id: “lecteur” 
            } 
            }); 
            }  

        </script> 
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PWWWBX"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  </body>
</html>